package id.kampus.attendance.mobile;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends ComponentActivity {
    private static final String API = "http://10.0.2.2:8080/api";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private LinearLayout eventContainer;
    private TextView status;
    private ActivityResultLauncher<ScanOptions> scanner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        scanner = registerForActivityResult(new ScanContract(), result -> {
            if (result.getContents() != null) {
                checkIn(result.getContents());
            } else {
                showStatus("Pemindaian dibatalkan.");
            }
        });
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 20);
        TextView title = new TextView(this);
        title.setText("Kehadiran & Event QR");
        title.setTextSize(24);
        root.addView(title);
        Button refresh = new Button(this);
        refresh.setText("Muat event");
        refresh.setOnClickListener(view -> loadEvents());
        root.addView(refresh);
        Button scan = new Button(this);
        scan.setText("Pindai QR peserta");
        scan.setOnClickListener(view -> scanner.launch(new ScanOptions()
                .setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                .setPrompt("Arahkan kamera ke QR peserta")));
        root.addView(scan);
        eventContainer = new LinearLayout(this);
        eventContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(eventContainer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1));
        status = new TextView(this);
        status.setText("Terhubung ke " + API);
        root.addView(status);
        setContentView(root);
        loadEvents();
    }

    private void loadEvents() {
        executor.execute(() -> {
            try {
                String response = request("GET", "/events", null);
                JSONArray events = new JSONArray(response);
                runOnUiThread(() -> {
                    eventContainer.removeAllViews();
                    for (int i = 0; i < events.length(); i++) {
                        JSONObject event = events.optJSONObject(i);
                        if (event == null) continue;
                        TextView item = new TextView(this);
                        item.setText(event.optString("name") + "\n" + event.optString("location")
                                + " • " + event.optString("startsAt")
                                + " • " + event.optInt("registeredCount") + "/" + event.optInt("capacity") + " peserta");
                        item.setTextSize(16);
                        item.setPadding(8, 18, 8, 18);
                        eventContainer.addView(item);
                    }
                    status.setText(events.length() + " event tersedia. Pindai QR peserta untuk check-in.");
                });
            } catch (Exception error) {
                showStatus("Gagal memuat event: " + error.getMessage());
            }
        });
    }

    private void checkIn(String token) {
        executor.execute(() -> {
            try {
                JSONObject payload = new JSONObject().put("qrToken", token);
                String response = request("POST", "/check-in", payload.toString());
                JSONObject result = new JSONObject(response);
                showStatus(result.optString("message") + ": " + result.optString("participantName")
                        + " — " + result.optString("eventName"));
            } catch (Exception error) {
                showStatus("Check-in gagal: " + error.getMessage());
            }
        });
    }

    private String request(String method, String path, String body) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) new URL(API + path).openConnection();
        connection.setRequestMethod(method);
        connection.setConnectTimeout(8000);
        connection.setReadTimeout(8000);
        if (body != null) {
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.getOutputStream().write(body.getBytes(StandardCharsets.UTF_8));
        }
        int code = connection.getResponseCode();
        var stream = code >= 200 && code < 300 ? connection.getInputStream() : connection.getErrorStream();
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        int bytesRead;
        while ((bytesRead = stream.read(buffer)) != -1) {
            output.write(buffer, 0, bytesRead);
        }
        String response = output.toString(StandardCharsets.UTF_8.name());
        connection.disconnect();
        if (code < 200 || code >= 300) throw new IOException("HTTP " + code + ": " + response);
        return response;
    }

    private void showStatus(String message) {
        runOnUiThread(() -> status.setText(message));
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
