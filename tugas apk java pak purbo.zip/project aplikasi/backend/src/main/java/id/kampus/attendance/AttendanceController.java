package id.kampus.attendance;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@Validated
@RestController
@RequestMapping("/api")
public class AttendanceController {
    private final EventRepository events;
    private final RegistrationRepository registrations;

    public AttendanceController(EventRepository events, RegistrationRepository registrations) {
        this.events = events;
        this.registrations = registrations;
    }

    @GetMapping("/events")
    public List<EventResponse> listEvents() {
        return events.findAll().stream()
                .map(event -> EventResponse.from(event, registrations.countByEventId(event.getId())))
                .toList();
    }

    @PostMapping("/events")
    public ResponseEntity<EventResponse> createEvent(@Valid @RequestBody CreateEventRequest request) {
        Event saved = events.save(new Event(
                request.name().trim(),
                request.location().trim(),
                request.startsAt(),
                request.capacity()));
        return ResponseEntity.status(HttpStatus.CREATED).body(EventResponse.from(saved, 0));
    }

    @PostMapping("/events/{eventId}/registrations")
    @Transactional
    public ResponseEntity<RegistrationResponse> register(
            @PathVariable("eventId") Long eventId,
            @Valid @RequestBody CreateRegistrationRequest request) {
        Event event = events.findById(eventId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Event tidak ditemukan"));
        if (registrations.existsByEventIdAndEmail(eventId, request.email().trim().toLowerCase())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email sudah terdaftar pada event ini");
        }
        if (registrations.countByEventId(eventId) >= event.getCapacity()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Kapasitas event sudah penuh");
        }
        Registration saved = registrations.save(new Registration(
                request.name().trim(),
                request.email().trim().toLowerCase(),
                UUID.randomUUID().toString(),
                event));
        return ResponseEntity.status(HttpStatus.CREATED).body(RegistrationResponse.from(saved));
    }

    @GetMapping("/events/{eventId}/attendances")
    public List<AttendanceResponse> listAttendances(@PathVariable("eventId") Long eventId) {
        if (!events.existsById(eventId)) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Event tidak ditemukan");
        }
        return registrations.findByEventIdOrderByNameAsc(eventId).stream()
                .map(AttendanceResponse::from).toList();
    }

    @PostMapping("/check-in")
    @Transactional
    public CheckInResponse checkIn(@Valid @RequestBody CheckInRequest request) {
        Registration registration = registrations.findByQrToken(request.qrToken().trim())
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "QR tidak valid"));
        LocalDateTime checkedInAt = LocalDateTime.now();
        if (registrations.markCheckedIn(registration.getQrToken(), checkedInAt) != 1) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "QR sudah pernah digunakan untuk check-in");
        }
        return new CheckInResponse(
                "Check-in berhasil",
                registration.getName(),
                registration.getEvent().getName(),
                checkedInAt);
    }

    public record CreateEventRequest(
            @NotBlank String name,
            @NotBlank String location,
            @NotNull LocalDateTime startsAt,
            @Positive int capacity) {
    }

    public record CreateRegistrationRequest(@NotBlank String name, @Email @NotBlank String email) {
    }

    public record CheckInRequest(@NotBlank String qrToken) {
    }

    public record EventResponse(Long id, String name, String location, LocalDateTime startsAt, int capacity,
                                long registeredCount) {
        static EventResponse from(Event event, long registeredCount) {
            return new EventResponse(event.getId(), event.getName(), event.getLocation(), event.getStartsAt(),
                    event.getCapacity(), registeredCount);
        }
    }

    public record RegistrationResponse(Long id, String name, String email, String qrToken, Long eventId) {
        static RegistrationResponse from(Registration registration) {
            return new RegistrationResponse(registration.getId(), registration.getName(), registration.getEmail(),
                    registration.getQrToken(), registration.getEvent().getId());
        }
    }

    public record AttendanceResponse(Long id, String name, String email, LocalDateTime checkedInAt) {
        static AttendanceResponse from(Registration registration) {
            return new AttendanceResponse(registration.getId(), registration.getName(), registration.getEmail(),
                    registration.getCheckedInAt());
        }
    }

    public record CheckInResponse(String message, String participantName, String eventName,
                                  LocalDateTime checkedInAt) {
    }
}
