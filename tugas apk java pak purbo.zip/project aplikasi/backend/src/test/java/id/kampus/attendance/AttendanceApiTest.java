package id.kampus.attendance;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

@SpringBootTest(properties = {
        "spring.datasource.url=jdbc:h2:mem:attendance-test;DB_CLOSE_DELAY=-1",
        "spring.jpa.hibernate.ddl-auto=create-drop"
})
@AutoConfigureMockMvc
class AttendanceApiTest {
    @Autowired
    private MockMvc mvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void registrationCanCheckInOnlyOnce() throws Exception {
        MvcResult eventResult = mvc.perform(post("/api/events")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"Test event","location":"Aula","startsAt":"2026-10-10T09:00:00","capacity":1}
                                """))
                .andExpect(status().isCreated())
                .andReturn();
        long eventId = objectMapper.readTree(eventResult.getResponse().getContentAsString()).get("id").asLong();

        MvcResult registrationResult = mvc.perform(post("/api/events/{id}/registrations", eventId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"Peserta Tes","email":"peserta@example.test"}
                                """))
                .andExpect(status().isCreated())
                .andReturn();
        JsonNode registration = objectMapper.readTree(registrationResult.getResponse().getContentAsString());
        String checkInBody = objectMapper.createObjectNode()
                .put("qrToken", registration.get("qrToken").asText()).toString();

        mvc.perform(post("/api/check-in").contentType(MediaType.APPLICATION_JSON).content(checkInBody))
                .andExpect(status().isOk());
        mvc.perform(post("/api/check-in").contentType(MediaType.APPLICATION_JSON).content(checkInBody))
                .andExpect(status().isConflict());
    }

    @Test
    void registrationRejectsDuplicateEmail() throws Exception {
        MvcResult eventResult = mvc.perform(post("/api/events")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {"name":"Duplicate test","location":"Aula","startsAt":"2026-10-10T09:00:00","capacity":2}
                                """))
                .andExpect(status().isCreated())
                .andReturn();
        long eventId = objectMapper.readTree(eventResult.getResponse().getContentAsString()).get("id").asLong();
        String registration = """
                {"name":"Peserta Tes","email":"DUplikat@example.test"}
                """;

        mvc.perform(post("/api/events/{id}/registrations", eventId)
                        .contentType(MediaType.APPLICATION_JSON).content(registration))
                .andExpect(status().isCreated());
        mvc.perform(post("/api/events/{id}/registrations", eventId)
                        .contentType(MediaType.APPLICATION_JSON).content(registration))
                .andExpect(status().isConflict());
    }
}
