package id.kampus.attendance;

import java.util.List;
import java.util.Optional;
import java.time.LocalDateTime;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegistrationRepository extends JpaRepository<Registration, Long> {
    List<Registration> findByEventIdOrderByNameAsc(Long eventId);
    Optional<Registration> findByQrToken(String qrToken);
    long countByEventId(Long eventId);
    boolean existsByEventIdAndEmail(Long eventId, String email);

    @Modifying
    @Query("update Registration r set r.checkedInAt = :checkedInAt "
            + "where r.qrToken = :qrToken and r.checkedInAt is null")
    int markCheckedIn(@Param("qrToken") String qrToken, @Param("checkedInAt") LocalDateTime checkedInAt);
}
