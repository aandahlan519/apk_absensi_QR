# Aplikasi Absensi & Event Berbasis QR

Aplikasi full-stack Java untuk mengelola event dan absensi dengan QR. Backend REST Spring Boot dan aplikasi desktop JavaFX menggunakan database yang sama. Aplikasi Android dapat memindai QR peserta untuk check-in.

## Fitur MVP

- Membuat event dengan nama, lokasi, tanggal, dan kapasitas.
- Mendaftarkan peserta pada event dan membuat token QR unik.
- Menampilkan QR peserta melalui aplikasi desktop.
- Memindai QR dari aplikasi Android dan mencatat waktu check-in.
- Menolak pendaftaran duplikat, kapasitas penuh, QR tidak dikenal, dan pemakaian QR kedua kali.
- Menyimpan data dalam database H2 lokal.

## Menjalankan dari Apache NetBeans

1. Pasang JDK 17 atau lebih baru dan Apache NetBeans yang mendukung proyek Maven.
2. Di NetBeans, pilih **File > Open Project**, lalu pilih folder proyek ini (folder yang berisi `pom.xml`).
3. Tunggu NetBeans menyelesaikan pemuatan proyek Maven. Backend dan desktop akan muncul sebagai modul.
4. Jalankan backend terlebih dahulu dengan membuka terminal NetBeans pada folder proyek lalu menjalankan:

   ```powershell
   mvn -pl backend spring-boot:run
   ```

5. Jalankan aplikasi pengelola desktop pada terminal NetBeans kedua:

   ```powershell
   mvn -pl desktop javafx:run
   ```

   Jika Maven tidak tersedia pada `PATH`, jalankan kedua perintah tersebut dari menu konteks modul terkait di NetBeans dengan aksi **Run Maven > Goals...**.

API berjalan pada `http://localhost:8080/api`. Jendela desktop memungkinkan pengelola membuat event, mendaftarkan peserta, menampilkan QR, dan membuka laporan kehadiran. Gunakan aplikasi Android untuk memindai QR saat check-in.

## Menjalankan backend secara terpisah

Butuh JDK 17+ dan Maven 3.9+.

```powershell
cd backend
mvn spring-boot:run
```

API aktif di `http://localhost:8080/api`. Database tersimpan di `backend/data/attendance`.

Endpoint utama:

| Method | Endpoint | Fungsi |
| --- | --- | --- |
| GET | `/api/events` | Daftar event |
| POST | `/api/events` | Membuat event |
| POST | `/api/events/{eventId}/registrations` | Mendaftarkan peserta dan mendapat token QR |
| GET | `/api/events/{eventId}/attendances` | Melihat peserta serta waktu check-in |
| POST | `/api/check-in` | Check-in dengan `{"qrToken":"..."}` |

Contoh membuat event:

```json
{
  "name": "Seminar Teknologi",
  "location": "Aula Kampus",
  "startsAt": "2026-10-10T09:00:00",
  "capacity": 100
}
```

## Aplikasi desktop

Aplikasi desktop menggunakan JavaFX dan secara default memakai `http://localhost:8080/api`. Jalankan backend lebih dahulu. URL API dapat diubah dengan properti JVM `-Dattendance.api=http://host:8080/api`.

```powershell
mvn -pl desktop javafx:run
```

## Aplikasi Android

Butuh Android Studio, Android SDK 35, dan JDK yang didukung oleh Android Gradle Plugin.

1. Buka folder `mobile` melalui Android Studio.
2. Jalankan aplikasi pada perangkat atau emulator.
3. Jalankan backend terlebih dahulu.
4. Emulator Android memakai alamat `10.0.2.2` untuk mengakses `localhost` komputer.

Untuk perangkat fisik, ubah konstanta `API` di `mobile/app/src/main/java/id/kampus/attendance/mobile/MainActivity.java` ke alamat IP komputer pada jaringan lokal, lalu pastikan firewall mengizinkan port 8080.

## Catatan pengembangan

Ini fondasi MVP untuk demonstrasi lokal, belum production-ready: autentikasi/otorisasi admin, HTTPS, pengelolaan secret, backup database, serta deployment server perlu ditambahkan sebelum penggunaan nyata. QR berisi token acak unik, bukan informasi pribadi peserta.
