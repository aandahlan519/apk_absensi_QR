package id.kampus.attendance.desktop;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.qrcode.QRCodeWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AttendanceDesktopApp extends Application {
    private static final String API = System.getProperty("attendance.api", "http://localhost:8080/api");
    private static final HttpClient HTTP = HttpClient.newHttpClient();
    private static final Pattern EVENT = Pattern.compile(
            "\\{\"id\":(\\d+),\"name\":\"((?:\\\\.|[^\"])*)\",\"location\":\"((?:\\\\.|[^\"])*)\",\"startsAt\":\"([^\"]*)\",\"capacity\":(\\d+)");
    private static final Pattern ATTENDANCE = Pattern.compile(
            "\\{\"id\":(\\d+),\"name\":\"((?:\\\\.|[^\"])*)\",\"email\":\"((?:\\\\.|[^\"])*)\",\"checkedInAt\":(null|\"[^\"]*\")\\}");
    private final ListView<String> eventList = new ListView<>();
    private final TextField eventName = new TextField();
    private final TextField location = new TextField();
    private final TextField startsAt = new TextField(LocalDateTime.now().plusDays(1).withSecond(0).withNano(0).toString());
    private final TextField capacity = new TextField("100");
    private final TextField selectedEventId = new TextField();
    private final TextField participantName = new TextField();
    private final TextField participantEmail = new TextField();
    private final ImageView qrImage = new ImageView();
    private final Label status = new Label("Menghubungkan ke API " + API);

    @Override
    public void start(Stage stage) {
        Button refresh = new Button("Muat event");
        refresh.setOnAction(event -> loadEvents());
        eventList.setPrefHeight(250);
        eventList.setOnMouseClicked(event -> {
            String selected = eventList.getSelectionModel().getSelectedItem();
            if (selected != null) selectedEventId.setText(selected.substring(0, selected.indexOf(" | ")));
        });

        GridPane form = new GridPane();
        form.setHgap(8);
        form.setVgap(8);
        addRow(form, 0, "Nama event", eventName);
        addRow(form, 1, "Lokasi", location);
        addRow(form, 2, "Tanggal (yyyy-MM-ddTHH:mm)", startsAt);
        addRow(form, 3, "Kapasitas", capacity);
        Button createEvent = new Button("Buat event");
        createEvent.setOnAction(event -> createEvent());

        GridPane registration = new GridPane();
        registration.setHgap(8);
        registration.setVgap(8);
        addRow(registration, 0, "ID event terpilih", selectedEventId);
        addRow(registration, 1, "Nama peserta", participantName);
        addRow(registration, 2, "Email peserta", participantEmail);
        Button register = new Button("Daftarkan & buat QR");
        register.setOnAction(event -> registerParticipant());
        Button attendanceReport = new Button("Lihat laporan kehadiran");
        attendanceReport.setOnAction(event -> loadAttendanceReport());
        qrImage.setFitWidth(210);
        qrImage.setFitHeight(210);
        qrImage.setPreserveRatio(true);

        VBox left = new VBox(10, new HBox(8, new Label("Daftar event"), refresh), eventList, attendanceReport,
                new Label("Buat event"), form, createEvent);
        VBox right = new VBox(10, new Label("Pendaftaran peserta"), registration, register, qrImage);
        BorderPane root = new BorderPane();
        root.setPadding(new Insets(18));
        root.setLeft(left);
        root.setCenter(right);
        BorderPane.setMargin(right, new Insets(0, 0, 0, 24));
        root.setBottom(status);
        stage.setTitle("Manajemen Kehadiran & Event QR");
        stage.setScene(new Scene(root, 920, 680));
        stage.show();
        loadEvents();
    }

    private static void addRow(GridPane grid, int row, String label, TextField field) {
        grid.addRow(row, new Label(label), field);
        field.setPrefWidth(270);
    }

    private void loadEvents() {
        HttpRequest request = HttpRequest.newBuilder(URI.create(API + "/events")).GET().build();
        HTTP.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> Platform.runLater(() -> {
                    if (response.statusCode() != 200) {
                        showError("Gagal memuat event: HTTP " + response.statusCode());
                        return;
                    }
                    eventList.getItems().clear();
                    Matcher matcher = EVENT.matcher(response.body());
                    while (matcher.find()) {
                        eventList.getItems().add(matcher.group(1) + " | " + unescape(matcher.group(2))
                                + " | " + unescape(matcher.group(3)) + " | " + matcher.group(4));
                    }
                    status.setText("Terhubung. " + eventList.getItems().size() + " event tersedia.");
                }))
                .exceptionally(error -> {
                    Platform.runLater(() -> showError("Tidak dapat menghubungi API: " + error.getMessage()));
                    return null;
                });
    }

    private void createEvent() {
        String body = "{\"name\":\"" + escape(eventName.getText()) + "\",\"location\":\""
                + escape(location.getText()) + "\",\"startsAt\":\"" + escape(startsAt.getText())
                + "\",\"capacity\":" + capacity.getText() + "}";
        sendPost("/events", body, "Event berhasil dibuat", ignored -> loadEvents());
    }

    private void registerParticipant() {
        if (selectedEventId.getText().isBlank()) {
            showError("Pilih event dari daftar terlebih dahulu.");
            return;
        }
        String body = "{\"name\":\"" + escape(participantName.getText()) + "\",\"email\":\""
                + escape(participantEmail.getText()) + "\"}";
        sendPost("/events/" + selectedEventId.getText() + "/registrations", body,
                "Peserta terdaftar", this::showQrFromResponse);
    }

    private void loadAttendanceReport() {
        if (selectedEventId.getText().isBlank()) {
            showError("Pilih event dari daftar terlebih dahulu.");
            return;
        }
        HttpRequest request = HttpRequest.newBuilder(
                URI.create(API + "/events/" + selectedEventId.getText() + "/attendances")).GET().build();
        HTTP.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> Platform.runLater(() -> {
                    if (response.statusCode() != 200) {
                        showError("Gagal memuat laporan: HTTP " + response.statusCode() + " " + response.body());
                        return;
                    }
                    StringBuilder report = new StringBuilder();
                    Matcher matcher = ATTENDANCE.matcher(response.body());
                    while (matcher.find()) {
                        report.append(unescape(matcher.group(2))).append(" <")
                                .append(unescape(matcher.group(3))).append("> — ")
                                .append("null".equals(matcher.group(4)) ? "Belum hadir" : "Sudah check-in")
                                .append('\n');
                    }
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Laporan kehadiran");
                    alert.setHeaderText("Total peserta terdaftar: " + countAttendances(response.body()));
                    alert.setContentText(report.length() == 0 ? "Belum ada peserta terdaftar." : report.toString());
                    alert.show();
                }))
                .exceptionally(error -> {
                    Platform.runLater(() -> showError("Tidak dapat menghubungi API: " + error.getMessage()));
                    return null;
                });
    }

    private static int countAttendances(String responseBody) {
        Matcher matcher = ATTENDANCE.matcher(responseBody);
        int count = 0;
        while (matcher.find()) count++;
        return count;
    }

    private void showQrFromResponse(String responseBody) {
        Matcher token = Pattern.compile("\"qrToken\":\"([^\"]+)\"").matcher(responseBody);
        if (!token.find()) {
            showError("API tidak mengembalikan token QR.");
            return;
        }
        try {
            var matrix = new QRCodeWriter().encode(token.group(1), BarcodeFormat.QR_CODE, 280, 280);
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            MatrixToImageWriter.writeToStream(matrix, "PNG", output);
            qrImage.setImage(new Image(new java.io.ByteArrayInputStream(output.toByteArray())));
            status.setText("QR peserta berhasil dibuat. Tampilkan QR ini saat check-in.");
        } catch (WriterException | IOException error) {
            showError("Gagal membuat QR: " + error.getMessage());
        }
    }

    private void sendPost(String path, String body, String success, java.util.function.Consumer<String> afterSuccess) {
        HttpRequest request = HttpRequest.newBuilder(URI.create(API + path))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body, StandardCharsets.UTF_8))
                .build();
        HTTP.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenAccept(response -> Platform.runLater(() -> {
                    if (response.statusCode() < 200 || response.statusCode() >= 300) {
                        showError("Permintaan gagal (HTTP " + response.statusCode() + "): " + response.body());
                        return;
                    }
                    status.setText(success);
                    afterSuccess.accept(response.body());
                }))
                .exceptionally(error -> {
                    Platform.runLater(() -> showError("Tidak dapat menghubungi API: " + error.getMessage()));
                    return null;
                });
    }

    private static String escape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", "\\n").replace("\r", "\\r");
    }

    private static String unescape(String value) {
        return value.replace("\\\"", "\"").replace("\\\\", "\\");
    }

    private static void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR, message);
        alert.setHeaderText("Terjadi kesalahan");
        alert.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
